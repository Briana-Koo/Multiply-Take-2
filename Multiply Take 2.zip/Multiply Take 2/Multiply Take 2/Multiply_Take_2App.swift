//
//  Multiply_Take_2App.swift
//  Multiply Take 2
//
//  Created by Student on 9/14/21.
//

import SwiftUI

@main
struct Multiply_Take_2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
